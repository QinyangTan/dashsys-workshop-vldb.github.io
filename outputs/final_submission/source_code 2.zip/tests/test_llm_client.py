from __future__ import annotations

from dashagent.llm_client import NoOpLLMClient, OpenAILLMClient


def test_noop_llm_client_skips_without_key(monkeypatch):
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    client = NoOpLLMClient()
    result = client.generate("system", "user")
    assert not client.available()
    assert result["skipped"] is True
    assert result["reason"] == "OPENAI_API_KEY is not set"


def test_openai_client_unavailable_without_key(monkeypatch):
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    client = OpenAILLMClient()
    assert not client.available()
    assert client.provider_name() == "none"
    result = client.generate("system", "user")
    assert result["skipped"] is True


def test_openai_generate_messages_normalizes_native_tool_calls(monkeypatch):
    class FakeResponse:
        ok = True

        def json(self):
            return {
                "choices": [
                    {
                        "finish_reason": "tool_calls",
                        "message": {
                            "role": "assistant",
                            "content": None,
                            "tool_calls": [
                                {
                                    "id": "call_1",
                                    "type": "function",
                                    "function": {
                                        "name": "execute_sql",
                                        "arguments": '{"sql":"SELECT 1"}',
                                    },
                                }
                            ],
                        },
                    }
                ],
                "usage": {"total_tokens": 10},
            }

    def fake_post(*args, **kwargs):
        return FakeResponse()

    monkeypatch.setattr("dashagent.llm_client.requests.post", fake_post)
    client = OpenAILLMClient(api_key="sk-test")
    result = client.generate_messages(
        [{"role": "user", "content": "How many?"}],
        tools=[{"type": "function", "function": {"name": "execute_sql", "parameters": {"type": "object"}}}],
        tool_choice="auto",
    )
    assert result["ok"] is True
    assert result["finish_reason"] == "tool_calls"
    assert result["tool_calls"] == [
        {
            "id": "call_1",
            "type": "function",
            "tool": "execute_sql",
            "name": "execute_sql",
            "arguments": {"sql": "SELECT 1"},
            "raw_arguments": '{"sql":"SELECT 1"}',
        }
    ]
